package in.org.timemanagement.timemanagement;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by Lovesh on 08-Jan-17.
 */

public class ListAdapter extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] web;
    private final String[] num;

    public ListAdapter(Activity context, String[] web, String[] imageId) {

        super(context, R.layout.listitem, web);

        this.context = context;
        this.web = web;
        this.num = imageId;

    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.listitem, null, true);

        TextView txtTitle = (TextView) rowView.findViewById(R.id.text_1);
        TextView txtNUmb = (TextView) rowView.findViewById(R.id.text_2);
        txtTitle.setText(web[position]);
        txtNUmb.setText(num[position]);

        return rowView;
    }
}
