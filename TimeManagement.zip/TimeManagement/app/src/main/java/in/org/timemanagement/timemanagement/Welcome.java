package in.org.timemanagement.timemanagement;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

public class Welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run (){
                Intent i = new Intent(Welcome.this, enter.class);
                startActivity(i);
                finish();
            }
        },5000);
        TextView welcome = (TextView) findViewById(R.id.welcome);
        ImageView image = (ImageView) findViewById(R.id.smile);

        YoYo.with(Techniques.ZoomIn)
                .duration(2000)
                .playOn(welcome);

        YoYo.with(Techniques.Bounce)
                .duration(2000)
                .delay(2000)
                .playOn(image);
    }
}
