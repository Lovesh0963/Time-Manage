package in.org.timemanagement.timemanagement;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

    ListView list;

    String[] web = {"ELECTRONIC DEVICES & CIRCUITS"," DATA STRUCTURES & ALGORITHMS","DIGITAL ELECTRONICS",
            "LINUX AND SHELL PROGRAMMING"," OBJECT ORIENTED PROGRAMMING"," Advanced Engineering Mathematics"};

    String[] num = { "01/01/17-05/01/17","06/01/17-10/01/17","11/01/17-15/01/17","16/01/17-20/01/17","21/01/17-25/01/17","26/01/17-30/01/"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       ListAdapter adapter = new ListAdapter(MainActivity.this, web, num);

        list=(ListView) findViewById(R.id.list_view);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();

            }
        });

    }

}






